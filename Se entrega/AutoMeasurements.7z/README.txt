AutoMeasurements

Install dependencies using "pip install -r requirements.txt"
Execute guiElements.py to run
