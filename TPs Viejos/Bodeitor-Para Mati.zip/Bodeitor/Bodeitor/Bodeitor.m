classdef Bodeitor < handle
    
    properties     
        handles;
        impObj = '';
        constr = {};
        mode = 1;
        freq = [];
        freqInd = 1;
        data1 = [];
        data2 = [];
        getting = false;
        loglin = 'log';
        autoosc = true;
    end
     
    methods
        
        function this = Bodeitor
            hfig = hgload('BodeitorGUI.fig');
            this.handles = guihandles(hfig);
            movegui(hfig, 'center');
            
            set(this.handles.connectbut, 'Callback', @(src, event) connectSelect(this, src, event));
            set(this.handles.refreshbut, 'Callback', @(src, event) refreshSelect(this, src, event));
            set(this.handles.logbut, 'Callback', @(src, event) loglinSelect(this, src, event));
            set(this.handles.linbut, 'Callback', @(src, event) loglinSelect(this, src, event));
            set(this.handles.autooscbut, 'Callback', @(src, event) autooscSelect(this, src, event));
            set(this.handles.bodetoggle, 'Callback', @(src, event) bodeSelect(this, src, event));
            set(this.handles.ztoggle, 'Callback', @(src, event) zSelect(this, src, event));
            set(this.handles.ltoggle, 'Callback', @(src, event) lSelect(this, src, event));
            set(this.handles.ctoggle, 'Callback', @(src, event) cSelect(this, src, event));
            set(this.handles.rtoggle, 'Callback', @(src, event) rSelect(this, src, event));
            set(this.handles.startbut, 'Callback', @(src, event) startSelect(this, src, event));
            set(this.handles.savebut, 'Callback', @(src, event) saveSelect(this, src, event));
            bg_image = imread('gridImg.png');
            set(this.handles.gridtoggle, 'Callback', @(src, event) gridSelect(this, src, event), 'CData', bg_image);
            
            set(findall(this.handles.freqPanel, '-property', 'enable'), 'enable', 'off');
            set(findall(this.handles.voscPanel, '-property', 'enable'), 'enable', 'off');
            set(findall(this.handles.selectPanel, '-property', 'enable'), 'enable', 'off');
            set(findall(this.handles.startPanel, '-property', 'enable'), 'enable', 'off');
            
            refreshSelect(this, this.handles.refreshbut, 0);
        end
        
        function this = connectSelect(this, src, ~)
            strList = get(this.handles.addressList, 'String');
            if strcmp(get(src, 'String'), 'Connect')
                if ~isempty(strList)
                    listVal = get(this.handles.addressList, 'Value');
                    this.impObj = eval(this.constr{listVal});
                    set(findall(this.handles.freqPanel, '-property', 'enable'), 'enable', 'on');
                    set(findall(this.handles.voscPanel, '-property', 'enable'), 'enable', 'on');
                    set(findall(this.handles.selectPanel, '-property', 'enable'), 'enable', 'on');
                    set(findall(this.handles.startPanel, '-property', 'enable'), 'enable', 'on');
                    set(this.handles.addressList, 'Enable', 'Off');
                    set(src, 'String', 'Disconnect');
                end
            else
                set(findall(this.handles.freqPanel, '-property', 'enable'), 'enable', 'off');
                set(findall(this.handles.voscPanel, '-property', 'enable'), 'enable', 'off');
                set(findall(this.handles.selectPanel, '-property', 'enable'), 'enable', 'off');
                set(findall(this.handles.startPanel, '-property', 'enable'), 'enable', 'off');
                set(this.handles.addressList, 'Enable', 'On');
                this.getting = false;
                set(src, 'String', 'Connect');
            end
        end
        
        function this = refreshSelect(this, ~, ~)
            instrreset;
            visainfo = instrhwinfo('visa');
            adaptor = visainfo.InstalledAdaptors{end};
            instr = instrhwinfo('visa', adaptor);
            this.constr = {};
            strList = '';
            for k = 1:length(instr.ObjectConstructorName)
                this.constr{k} = instr.ObjectConstructorName{k};
                clStr = regexpi(this.constr{k}, '[a-z]*\(''[a-z]+''[ ]*,[ ]*''(?<resource>[A-Z0-9:]+)''', 'names');
                strList = [strList; clStr.resource];
            end
            set(this.handles.addressList, 'String', strList);
        end
        
        function this = loglinSelect(this, src, ~)
            if get(this.handles.logbut, 'Value')
                this.loglin = 'log';
            else
                this.loglin = 'lin';
            end
        end
        
        function this = autooscSelect(this, ~, ~)
            
        end
        
        function this = bodeSelect(this, ~, ~)
            this.mode = 1;
        end
        
        function this = zSelect(this, ~, ~)
            this.mode = 2;
        end
        
        function this = lSelect(this, ~, ~)
            this.mode = 3;
        end
        
        function this = cSelect(this, ~, ~)
            this.mode = 4;
        end
        
        function this = rSelect(this, ~, ~)
            this.mode = 5;
        end
        
        function this = startSelect(this, src, ~)
            if strcmp(get(src, 'String'), 'Start');
                fstart = str2double(get(this.handles.fstart, 'String'));
                fend = str2double(get(this.handles.fend, 'String'));
                npoints = str2double(get(this.handles.npoints, 'String'));
                if get(this.handles.logbut, 'Value')
                    this.freq = logspace(log10(fstart), log10(fend), npoints);
                else
                    this.freq = linspace(fstart, fend, npoints);
                end
                set(this.handles.savebut, 'Enable', 'Off');
                set(findall(this.handles.freqPanel, '-property', 'enable'), 'enable', 'off');
                set(findall(this.handles.voscPanel, '-property', 'enable'), 'enable', 'off');
                set(findall(this.handles.selectPanel, '-property', 'enable'), 'enable', 'off');
                set(src, 'String', 'Stop');
                try
                    this.getting = true;
                    fopen(this.impObj);
                    if get(this.handles.autooscbut, 'Value')
                        for k = 0.750:-0.005:0.010
                            fprintf(this.impObj, char(strcat('OL', num2str(k), 'EN')));
                            pause(0.01);
                            dataRead = fscanf(this.impObj);
                            dataRead = fscanf(this.impObj);
                            if dataRead(1) == 'N'
                                break;
                            end
                        end
                    else
                        vosc = str2double(get(this.handles.vosc, 'String'));
                        fprintf(this.impObj, char(strcat('OL', num2str(vosc), 'EN')));
                    end
                    this.selectMode();
                    for k = 1:npoints
                        this.freqInd = k;
                        fprintf(this.impObj, 'FR%fEN', this.freq(k)*1e-3);
                        if this.mode == 1
                            pause(5/this.freq(k));
                        else
                            pause(0.5);
                        end
                        try
                            if this.getting
                                dataRead = fscanf(this.impObj);
                                dataRead = fscanf(this.impObj);
                                this.data1(k) = str2double(dataRead(1, 5:15));
                                pause(0.01);
                                this.data2(k) = str2double(dataRead(1, 21:31));
                            else
                                this.getting = false;
                                fclose(this.impObj);
                                break;
                            end
                            
                            plot1 = plot(this.handles.axes1, this.freq(1:this.freqInd), this.data1(1:this.freqInd));
                            set(plot1, 'LineWidth', 2);
                            set(this.handles.axes1, 'XScale', this.loglin);
                            xlim(this.handles.axes1, [fstart, fend]);
                            plot2 = plot(this.handles.axes2, this.freq(1:this.freqInd), this.data2(1:this.freqInd));
                            set(plot2, 'LineWidth', 2);
                            set(this.handles.axes2, 'XScale', this.loglin);
                            xlim(this.handles.axes2, [fstart, fend]);
                            if this.mode == 1
                                ylim(this.handles.axes1, [min(this.data1(1:this.freqInd))-1, max(this.data1(1:this.freqInd))+1]);
                                ylim(this.handles.axes2, [min(this.data2(1:this.freqInd))-1, max(this.data2(1:this.freqInd))+1]);
                            end
                            if get(this.handles.gridtoggle, 'Value')
                                grid(this.handles.axes1, 'On')
                                grid(this.handles.axes2, 'On')
                            else
                                grid(this.handles.axes1, 'Off')
                                grid(this.handles.axes2, 'Off')
                            end
                            this.axisValues();
                        catch
                            connectSelect(this, this.handles.connectbut, 0);
                            refreshSelect(this, this.handles.refreshbut, 0);
                            set(findall(this.handles.freqPanel, '-property', 'enable'), 'enable', 'off');
                            set(findall(this.handles.voscPanel, '-property', 'enable'), 'enable', 'off');
                            set(findall(this.handles.selectPanel, '-property', 'enable'), 'enable', 'off');
                            errordlg('Error: Impedance Anallyzer disconnected','Connection Error');
                            this.getting = false;
                            break;
                        end
                    end
                    if this.getting
                        fclose(this.impObj);
                        set(this.handles.savebut, 'Enable', 'On');
                        this.getting = false;
                    end
                    set(findall(this.handles.freqPanel, '-property', 'enable'), 'enable', 'on');
                    set(findall(this.handles.voscPanel, '-property', 'enable'), 'enable', 'on');
                    set(findall(this.handles.selectPanel, '-property', 'enable'), 'enable', 'on');
                catch
                    connectSelect(this, this.handles.connectbut, 0);
                    refreshSelect(this, this.handles.refreshbut, 0);
                    set(findall(this.handles.freqPanel, '-property', 'enable'), 'enable', 'off');
                    set(findall(this.handles.voscPanel, '-property', 'enable'), 'enable', 'off');
                    set(findall(this.handles.selectPanel, '-property', 'enable'), 'enable', 'off');
                    errordlg('Error: Impedance Anallyzer disconnected','Connection Error');
                    this.getting = false;
                end
                set(src, 'String', 'Start');
            else
                set(src, 'String', 'Stop');
                this.getting = false;
            end
        end
        
        function this = saveSelect(this, ~, ~)
            try
                [filename, pathname] = uiputfile('*.csv', 'Save .csv file');
                filepath = [pathname, filename];
                disp('Hola1')
                switch this.mode
                    case 1
                        header1 = 'Gain [dB]';
                        header2 = 'Phase [�]';
                    case 2
                        header1 = 'Impedance [Ohm]';
                        header2 = 'Phase [�]';
                    case 3
                        header1 = 'Inductance [H]';
                        header2 = 'Q Factor';
                    case 4
                        header1 = 'Capacitance [F]';
                        header2 = 'D Factor';
                    case 5
                        header1 = 'Resistance [Ohm]';
                        header2 = 'Reactance [Ohm]';
                end
                disp('Hola2')
                data = zeros(length(this.freq), 3);
                disp('Hola3')
                data(:,1) = this.freq';
                data(:,2) = this.data1';
                data(:,3) = this.data2';
                disp('Hola3')
                csvwriteh(filepath, data, {'Frequency [Hz]', header1, header2});
                msgbox('Successfully saved file', 'File saved');
            catch
                errordlg('Error: The output file is open. Please close it or change the output filename','File Error');
            end
        end
        
        function this = gridSelect(this, src, ~)
            if get(src, 'Value')
                grid(this.handles.axes1, 'On')
                grid(this.handles.axes2, 'On')
            else
                grid(this.handles.axes1, 'Off')
                grid(this.handles.axes2, 'Off')
            end
        end
        
        function selectMode(this)
            switch this.mode
                case 1
                    fprintf(this.impObj, 'A5B2EN');
                case 2
                    fprintf(this.impObj, 'A1B1EN');
                case 3
                    fprintf(this.impObj, 'A3B1EN');
                case 4
                    fprintf(this.impObj, 'A4B2EN');
                case 5
                    fprintf(this.impObj, 'A2B1EN');
            end
        end
        
        function axisValues(this)
            xlabel(this.handles.axes1, 'Frequency [Hz]');
            xlabel(this.handles.axes2, 'Frequency [Hz]');
            switch this.mode
                case 1
                    ylabel(this.handles.axes1, 'Gain [dB]');
                    ylabel(this.handles.axes2, 'Phase [�]');
                case 2
                    ylabel(this.handles.axes1, 'Impedance [\Omega]');
                    ylabel(this.handles.axes2, 'Phase [�]');
                case 3
                    ylabel(this.handles.axes1, 'Inductance [H]');
                    ylabel(this.handles.axes2, 'Q Factor');
                case 4
                    ylabel(this.handles.axes1, 'Capacitance [F]');
                    ylabel(this.handles.axes2, 'D Factor');
                case 5
                    ylabel(this.handles.axes1, 'Resistance [\Omega]');
                    ylabel(this.handles.axes2, 'Reactance [\Omega]');
            end
        end
    
    end
end
        